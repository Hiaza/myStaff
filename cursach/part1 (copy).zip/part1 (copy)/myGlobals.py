from PyQt5 import QtCore, QtGui, QtWidgets

l_curr_time = object;
scroll = object;
durality = 0
cur_time = 0    
thread1 = False
thread2 = False